package Exercises;

import java.util.Scanner;

public class menu {
    private static final double IVA = 0.05;//5%

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        double total = 0;

        while (true) {
            mostrarMenu();
            int opcionSeleccionada = scanner.nextInt();

            switch (opcionSeleccionada) {
                case 1:
                    especialDia();
                    total += (23000 - 1000);//Descuento
                    break;
                case 2:
                    platosEspeciales();
                    total += (25000 - 1500);//Descuento
                    break;
                case 3:
                    ensaladas();
                    total += 6000;//No aplica al descuento
                    break;
                case 4:
                    desayunos();
                    total += (15000 - 1000);//Descuento
                    break;
                case 5:
                    postres();
                    total += 8000;//No hay Descuento
                    break;
                case 6:
                    adicionales();
                    total += 3000;//No hay descuento
                    break;
                case 7:
                    bebidas();
                    total += 7000;
                    break;
                case 8:
                    double totalConIVA = total + (total * IVA);//Iva del 5%
                    System.out.println("Total a pagar (Iva Incluido):$" + totalConIVA);
                    System.out.println("Gracias por tu pedido¡Que tengas Un Lindo Dia!");
                    return;
                default:
                    System.out.println("Opción No valida.Por favor,Selecciona una opción valida del menú");
                    break;
            }
            System.out.println("¿Deseas Seleccionar otra opción del menú?(Si/No)");
            String respuesta = scanner.next();
            if (respuesta.equalsIgnoreCase("No")) {
                System.out.println("El total a pagar (Iva Incluido) :" + total);
                System.out.println("Gracias por tu pedido¡Que tengas Un Lindo Dia!");
            }
            return;

        }
    }

    private static void mostrarMenu() {
        System.out.println("Menu Del Restaurante");
        System.out.println("1.Especialidad $23.000");
        System.out.println("2.Platos especiales $25.000");
        System.out.println("3.Ensaladas $6.000");
        System.out.println("4.Desayunos $15.000");
        System.out.println("5.Postres $8.000");
        System.out.println("6.Adicionales $3.000");
        System.out.println("7.Bebidas $7.000");
        System.out.println("8.salir");
        System.out.println("Selecciona Una Opción");
    }
    private static void especialDia(){
        System.out.println("Elegiste Especialidad:Nuestro plato mas destacado");
        System.out.println("Los Ingredientes Son : Pechuga a la plancha,Papas a la francesa,Ensalada,Arroz y Jugo de Mora");
    }

    private static void platosEspeciales() {
        System.out.println("Elegiste Platos Especiales:Platos Unicos y Deliciosos");
        System.out.println("1.Churrasco");
        System.out.println("2.Lomo de cerdo en salsa agridulce");
        System.out.println("3.Lengua en salsa");
        System.out.println("4.bagre en salsa");
        System.out.println("5.Costilla de cerdo ahumado");
        System.out.println("Selecciona Un Opción de Plato Especial");
    }

    private static void ensaladas() {
        System.out.println("Elegiste Ensaladas:Plato saludable");
        System.out.println("1.Ensalada de vegetales");
        System.out.println("2.Ensalada de Frutas");
        System.out.println("3.Ensalada de Papa");
        System.out.println("4.Ensalada de zanahoria con papa");
        System.out.println("Selecciona una Opción deEnsalada");
    }

    private static void desayunos() {
        System.out.println("Elegiste Desayunos:Comienza el dia con Energía");
        System.out.println("1.Tamal con arepa y chocolate");
        System.out.println("2.Caldo de pajarilla,arepa,chocolate y pan");
        System.out.println("3.Caldo de costilla,arepa,chocolate y pan");
        System.out.println("4.Calentado,arepa,chocolate y pan");
        System.out.println("Selecciona un Opción de Desayuno");
    }

    private static void postres() {
        System.out.println("Elegiste Postres:¡Dulces Tentaciones");
        System.out.println("1.Postre de Maracuyá");
        System.out.println("2.Fland de Limón");
        System.out.println("3.Helado");
        System.out.println("4.Postre de Oreo");
        System.out.println("5.Oblea");
        System.out.println("Selecciona un Opción de Postres");
    }
    private static  void adicionales(){
        System.out.println("Elegiste Adicionales : Añade extras a tu plato");
        System.out.println("1.Porción de Papas Fritas");
        System.out.println("2.Arroz");
        System.out.println("3.Arepa");
        System.out.println("4.Papa Saladas");
        System.out.println("Selecciona un Opción de Adicionales");
    }
    private static  void bebidas(){
        System.out.println("Elegiste Bebidas:Refrescate con nuestras bebidas");
        System.out.println("1.Jarra de Jugo de Guanábana con Leche");
        System.out.println("2.Jarra de Jugo de Limonada  de Coco");
        System.out.println("Selecciona un Opción de Bebidas");

    }

}