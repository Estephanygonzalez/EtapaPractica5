package PatronesDeDiseño;

class Singleton {

    //Programa Java que implementa la clase Singleton
    //Usando el metodo getInstance
    // Clase 1
    // Clase auxiliar
    // Referencia de variable estática de instancia_única
    // de tipo Singleton
            private static Singleton single_instance = null;

            // Declara una variable tipo String
            public String s;

            // Constructor
            // Aquí crearemos un constructor privado.
            // restringido a esta clase misma
            private Singleton()
            {
                s = "Hello I am a string part of Singleton class";
            }

            // Metodo estatico
            // metodo estatico crea una instancia de la clase singleton
            public static synchronized Singleton getInstance()
            {
                if (single_instance == null)
                    single_instance = new Singleton();

                return single_instance;
            }
        }

