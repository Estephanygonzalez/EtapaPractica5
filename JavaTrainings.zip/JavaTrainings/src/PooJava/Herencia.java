package PooJava;

public class Herencia {
}
