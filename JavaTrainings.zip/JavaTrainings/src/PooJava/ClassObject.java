package PooJava;

import com.sun.tools.javac.Main;

public class ClassObject {
    static  void myMethod(){
        System.out.println("Static Methods");
    }
    int x = 5;
    String fname = "David";
    String lname = "Romero";
    int age = 24;

     final int y = 9;//No anular el valor o almacenarlo pero que no tenga cambios//
    public static void main(String[] args) {//myMethod  name method
        ClassObject myObj = new ClassObject();
        ClassObject myObj1 = new ClassObject();
        System.out.println("myObj = " + myObj.x);
        System.out.println("myObj1 = " + myObj1.y);
        myObj.x = 45;//Reasignar Valor//
        System.out.println("myObj.x = " + myObj.x);
        myObj1.x = 25;//Reasignarle un  valor a un Object
        System.out.println(myObj1.x);
        //MyClass myObj = new MyClass();//

        //Exercise 1)//
        ClassObject myObj2 = new ClassObject();
        System.out.println("Name = " + myObj2.fname + " " + myObj2.lname);
        System.out.println("Age:" + myObj2.age);

       /*
       public class MyClass {
       int x = 5;

       public static void main(String[] args) {
       MyClass myObj = new MyClass();
       System.out.println(myObj.x);
  }
}
        */
        /*
        public class MyClass {
        public void myMethod() {
        System.out.println("Hello World");
        }
        public static void main(String[] args) {
        MyClass myObj = new MyClass();
        myObj.myMethod();
  }
}
         */











        
    }
}
