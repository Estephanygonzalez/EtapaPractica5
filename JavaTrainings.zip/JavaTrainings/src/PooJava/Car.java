package PooJava;

public class Car {
    public void  fullThrottle(){
        System.out.println("The car is going as fat as it can!");
    }

    public void speed(int maxSpeed){
        System.out.println("maxSpeed = " + maxSpeed);
    }

    public static void main(String[] args) {
        Car myCar = new Car();
        myCar.fullThrottle();
        myCar.speed(200);
    }
}
//. Se utiliza para acceder a los atributos y methods del object//

