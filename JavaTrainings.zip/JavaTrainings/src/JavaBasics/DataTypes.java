package JavaBasics;

public class DataTypes {
    public static void main(String[] args) {

       int miNum = 9;
       float miNumFlotante = 8.99f;
       char miLetra ='A';
       boolean miBool = false;
       String miTexto = "Hola mundo";

        /*
        Se puede reemplazar Byte por int para almacenar
        numeros enteros de -128 a 127
         */
        byte myNum = 100;
        System.out.println(myNum);

        short myNum1 = 5000;
        System.out.println(myNum1);

        int myNum2 = 100000;
        System.out.println(myNum2);

        int myNum3 = 100000;
        System.out.println(myNum3);

        float f1 = 35e3f;
        double d1 = 12E4d;
        System.out.println(f1);
        System.out.println(d1);
        //'e' Indica la potencia de 10//


        //Boolean
        boolean isJavaFun = true;
        boolean isFishTasty = false;
        System.out.println(isJavaFun);
        System.out.println(isFishTasty);

        //Char
        char Letra= 'B';
        System.out.println(Letra);

        char myVar1 = 65, myVar2 = 66, myVar3 = 67;
        System.out.println(myVar1);
        System.out.println(myVar2);
        System.out.println(myVar3);


    }
}
