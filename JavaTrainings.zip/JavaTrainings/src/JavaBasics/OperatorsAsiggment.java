package JavaBasics;

public class OperatorsAsiggment {
    public static void main(String[] args) {

        //Operators Assigment

        int l= 10;//Asignar valor a la variable L

        int m = 10;
        m += 5;
        System.out.println(m);//suma += agrega un valor a la variable = 15


        m-=3;
        System.out.println("m = " + m);//Resta -=x

        m*=3;
        System.out.println("m = " + m);//Multiplication *=x

        m/=3;
        System.out.println("m = " + m);//division /=x

        m%=2;
        System.out.println("m = " + m);//modulus

        m&=3;
        System.out.println("m = " + m);

        m|=3;
        System.out.println("m = " + m);

        m^=3;
        System.out.println("m = " + m);

        m>>=3;
        System.out.println("m = " + m);

        m<<=3;
        System.out.println("m = " + m);

    }
}
