package JavaBasics;

import java.util.Scanner;

public class ExerciseOperators {
    public static void main(String[] args) {
        /*
        1)Dadas las horas trabajadas de una persona y el valor por hora calcular su salario e imprimirlo
         */
        int a,b,c;
        String name;
        Scanner scanner = new Scanner(System.in);
        System.out.println(" Ingrese  el nombre del trabajador");
        name = scanner.next();
        System.out.println("Ingrese la cantidad de horas trabajadas");
        a = scanner.nextInt();
        System.out.println("Ingrese el valor de la hora trabajada");
        b = scanner.nextInt();
        c = a * b;
        System.out.println("El salario del trabajador"+ name + "es;" +c);

    }
}
