package JavaBasics;

public class TypeCasting {
    public static void main(String[] args) {

        int su = 15350;
        long ma = 120000000;
        long suma = su+ma;

        int suma2 = (int) (su+ma);
        System.out.println("suma = " + suma);
        System.out.println("suma2 = " + suma2);


    }
}
