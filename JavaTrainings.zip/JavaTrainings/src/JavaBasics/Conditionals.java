package JavaBasics;

public class Conditionals {
    public static void main(String[] args) {
        if (20 > 18) {
            System.out.println("20 is greater than 18");
        }
        int x = 20;
        int y = 18;
        if (x > y) {
            System.out.println("x is greater than y");
        }

        int time = 20;
        if (time < 18) {
            System.out.println("Good day.");
        } else {
            System.out.println("Good evening.");
        }

        //Exercises
        //1)
        int a = 50;
        int b = 10;
        if (a > b) {
            System.out.println("Hello World");
        }
        //2)
        int c = 50;
        int d = 50;
        if (x == y) {
            System.out.println("Yes");
        }
        else {
            System.out.println("No");
        }

        int e = 50;
        int f = 50;
        if (e == f) {
            System.out.println("1");
        } else if (f> e) {
            System.out.println("2");
        }
        else {
            System.out.println("3");
        }

        //Operador ternario

        //variable = (condition) ? expressionTrue :  expressionFalse;
        //Para escribir de una forma mas corta el if/else
        int time1 = 20;
        String result = (time1 < 18) ? "Good day." : "Good evening.";
        System.out.println(result);


        //Switch,Examples

        int day = 4;
        switch (day) {
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            case 7:
                System.out.println("Sunday");
                break;
        }

        //Exercise

        /*
        int day = 2;
        switch (day) {
        case 1:
        System.out.println("Saturday");
        break;

        case 2:
        System.out.println("Sunday");
        break;
        }
        */
        //Example Number 2
        /*
        int day = 4;
        switch (day) {
        case1:
        System.out.println("Saturday");
        break;
        case 2:
        System.out.println("Sunday");
        break;
        default:
        System.out.println("Weekend");
         */

        //WHILE




    }
}
