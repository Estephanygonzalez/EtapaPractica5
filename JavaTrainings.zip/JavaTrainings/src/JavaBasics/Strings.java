package JavaBasics;

public class Strings {
    public static void main(String[] args) {

        //length
        String txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.out.println("The length of the txt string is: " + txt.length());


        //toUpperCase-toLowerCase
        String txt2 = "Hello World";
        System.out.println(txt.toUpperCase());   // Outputs "HELLO WORLD"
        System.out.println(txt.toLowerCase());   // Outputs "hello world"

        //IndexOf
        String txt4 = "Please locate where 'locate' occurs!";
        System.out.println(txt4.indexOf("locate"));

        //Exercises
        String greeting = "Hello";
        System.out.println("greeting = " + greeting);

        String txt1 = "Hello";
        System.out.println(txt1.length());

        String txt3 = "Adios";
        System.out.println(txt3.toUpperCase());


        //Concatenar
        String firstName = "John";
        String lastName = "Doe";
        System.out.println(firstName + " " + lastName);

        int x = 10;
        int y = 20;
        int z = x + y;

        String x1 = "10";
        String y2 = "20";
        String z1 = x1 + y2;

        String x2 = "10";
        int y1 = 20;
        String z2 = x2 + y1;

        String firstName1= "John ";
        String lastName1 = "Doe";
        System.out.println(firstName1.concat(lastName1));


        String vikingos = "We are the so-called \"Vikings\" from the north.";
        System.out.println(vikingos);

        String hola = "It\'s alright.";
        System.out.println("hola = " + hola);

        String txt5 = "Hello Everybody";
        System.out.println(txt.indexOf("e"));









    }
}
