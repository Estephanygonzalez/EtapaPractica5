package JavaBasics;

public class OperatorsLogic {
    public static void main(String[] args) {
        //Operadores Comparatives
        int x = 5;
        int y = 3;
        System.out.println(x > y);
        System.out.println(x == y);
        System.out.println(x != y);
        System.out.println(x > y);
        System.out.println(x < y);
        System.out.println(x <= y);
        System.out.println(x >= y);

        //Operadores Logical

        System.out.println(x > 3 && x<10);//&&And

        System.out.println(x > 3 || x < 4); //or ||

        System.out.println(!(x > 3 && x < 10));//Not!


        //Exercise
        System.out.println(10*5);

        System.out.println(10/5);

        int z= 10;
        ++x;

        int w = 10;
        w += 5;


    }
}
