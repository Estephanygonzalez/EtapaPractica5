package JavaBasics;

public class OperatorsAritmetic {
    public static void main(String[] args) {

        //Add
        int x = 100 + 50;
        System.out.println("x = " + x);
        int a = 23;
        int b = 4;
        int suma = a+b;
        System.out.println("El resultado de la suma es: " + suma);

        //Example +
        int sum1 = 100 + 50;        // 150 (100 + 50)
        System.out.println("sum1 = " + sum1);
        int sum2 = sum1 + 250;      // 400 (150 + 250)
        System.out.println("sum2 = " + sum2);
        int sum3 = sum2 + sum2;     // 800 (400 + 400)
        System.out.println("sum3 = " + sum3);

        //Substraction
        int c = 6;
        int d = 9;
        System.out.println(c-d);

        //Multiplication
        int e = 12;
        int f = 2;
        System.out.println(e*f);

        //Division
        System.out.println(e/c);
        int g = 9;
        int h = 4;
        System.out.println(g/h);

        //Modulus
        int i = 8;
        int j = 3;
        System.out.println(8%3);

        //Increment
        var k = 3;
        System.out.println(++k);

        //Decrement
        System.out.println(--k);






        







    }
}
