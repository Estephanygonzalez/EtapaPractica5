package JavaBasics;

public class MathJava {
    public static void main(String[] args) {
        System.out.println(Math.max(5,10));
        System.out.println(Math.min(6,10));
        System.out.println(Math.sqrt(64));//sqrt devuelve la raiz cuadrada
        System.out.println(Math.abs(-4.7));//convierte el numero a positivo
        System.out.println(Math.random());//numero al azar entre 0,0 y 1,0

        //numero aleatorio del 1 al 100
        int randomNum = (int)(Math.random() * 101);  // 0 to 100
        System.out.println(randomNum);

        //Exercise
        int x = 5;
        int y = 10;
        Math.max(x, y);

        int a = 16;
        Math.sqrt(a);


        //Boolean
        int l = 10;
        System.out.println(l == 10);

        System.out.println(10 == 15);//Boolean

        int myAge = 25;
        int votingAge = 18;
        System.out.println(myAge >= votingAge);

        //Example//
        int myAge1 = 25;
        int votingAge1 = 18;

        if (myAge1 >= votingAge1) {
            System.out.println("Old enough to vote!");
        } else {
            System.out.println("Not old enough to vote.");
        }

        int b = 10;
        int c = 9;
        System.out.println(b > c);
    }

    }

