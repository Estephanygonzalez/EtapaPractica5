package Streams;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Streams1 {
    public static void main(String[] args) {
        //Primitivo
        int opcion = 0 ;//scanner.nextInt()
        //wrapper
        Integer opcionSeleccionada = null;
        //primitivo
        float primerNumero = 0.0f;
        //wrapper
        Float segundoNumero = null;
        primerNumero = segundoNumero.floatValue();

        //Colecciones
        //Listas
        List<Integer>listaEnteros = new ArrayList<>();
        listaEnteros.add(2);
        listaEnteros.add(5);

        //Iterador posterios
        for (Integer entero :listaEnteros) System.out.println("Numero :"+entero);

        //version mejorada-desempeño y actual
        listaEnteros.stream().forEach(ele ->{
                    System.out.println(ele);});

        //wrapper Objetos que le dan una mejor funcionalidad mas alla a los datos primitivos

        //switch()

        //teoria + buenas Practicas

        //Solid +


    }
}
