// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.println("I am learning Java.");
        System.out.println(3);

        String saludo = "Hello world";
        System.out.println("saludo = " + saludo);

        String name = "John";
        System.out.println("nombre = " + name);

        int edad = 18;
        System.out.println("edad = " + edad);
        edad = 22;//Reasignar Variable//
        System.out.println("edad = " + edad);

        String carName = "Volvo";

        String nombre = "John";
        System.out.println("Hello " + nombre);

        String firstName = "John ";
        String lastName = "Doe";
        String fullName = firstName + lastName;
        System.out.println(fullName);

        String p;//Creacion de la variable p//
        p = "Hola Mundo";
        /*En este string asignamos el nombre de la
        variable a p y le asignamos un valor a la
        variable p
         */
        int p1 = 5;
        int p2 = 3;
        int p3 = 6;
        int suma = p1 + p2 + p3;
        float  p4 = 1.9f;
        System.out.println(" Este es el resultado = " +p1  +p);
        System.out.println("p1 = " + p1);
        System.out.println(p1+p2+p3);
        System.out.println("suma = " + suma);
        System.out.println(suma + p4);

        int num1 = 4;
        int num2 = 5;
        int mult = num1 * num2;
        System.out.println("El resultado de esta multiplicacion es = " + mult);

        int num3 = 8;
        int num4 = 2;
        int div = num3/ num4;
        System.out.println("El resultado de esta division es = " + div);

        int x = 5;
        int y = 6;
        System.out.println(x + y);

        int m = 5, n = 6, z = 50;
        System.out.println(m+ n + z);







    }

}